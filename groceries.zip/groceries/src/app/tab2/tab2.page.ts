import {Component} from '@angular/core';
import {GroceryItem} from "../grocery/grocery.item";

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})
export class Tab2Page {

  public groceries: Array<GroceryItem> = [];

  constructor() {
    this.groceries = [
      new GroceryItem('Eggs', 2, 3.99),
      new GroceryItem('Milk', 1, 5.00),
      new GroceryItem('Oranges', 6, 1.00),
      new GroceryItem('Bread Loaf', 1, 4.29),
      new GroceryItem('Chocolate Bar', 3, 1.99)
    ];
  }

}
